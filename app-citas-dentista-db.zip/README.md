# APP de Citas de Médico
Deberemos recoger en un documento las citas
que se van generando 
## Requisitos
1. Página de inserción de datos
    * nombre requerido
    * telefono requerido
    * email requerido
    fecha de solicitud (la genera el sistema) - PHP
    fecha de la cita (apuntamos: la cita será confirmada posteriormente)
    Observaciones
2. Recoger datos, filtrarlos y vemos que no están vacíos los requeridos
3. Mandarlos por email a la persona citada
4. Registran los datos en una  tabla general
## Pasos
Crear las interfaces (la vistas)
    Plantilla de recogida de datos
    Bootstrap y con iconos de bootstrap
    Crear parciales : header y footer
    Plantilla de muestra de datos
Procesaremos el formulario  (el controlador)
Registramos los datos (data)
